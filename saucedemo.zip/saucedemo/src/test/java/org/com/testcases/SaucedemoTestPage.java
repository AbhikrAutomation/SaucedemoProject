package org.com.testcases;

import org.com.Util.TestUtil;
import org.com.base.BaseMethodClass;
import org.com.pages.CartPage;
import org.com.pages.CheckoutPage;
import org.com.pages.InventoryPage;
import org.com.pages.LoginPage;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SaucedemoTestPage extends BaseMethodClass {
	LoginPage LP;
	InventoryPage IP;
	CartPage CP;
	CheckoutPage CHP;
	String sheetName = "Contacts";

	public SaucedemoTestPage(){
	super();
	}
	

	@BeforeMethod
	public void setUp() {
		initialization();
		 LP = new LoginPage();
		 IP = new InventoryPage();
		 CP = new CartPage();
		 CHP = new CheckoutPage();

	}
	

	@DataProvider
	public Object[][] getcontactsdata() {
		Object data[][]= TestUtil.getTestData(sheetName);
		return data;
	}

	@Test(priority=1, dataProvider = "getcontactsdata")
	public void ValidateCreateNewContacts(String firstName, String LastName , String PostalCode) throws InterruptedException {
		IP = LP.login(prop.getProperty("username"), prop.getProperty("password"));
		CP = IP.addItems();
		CHP = CP.checkItems();
		CHP.entercontactsDetails(firstName, LastName, PostalCode);

	}
	





	@AfterMethod
	public void tearDown() {
		driver.quit();
	}
}
