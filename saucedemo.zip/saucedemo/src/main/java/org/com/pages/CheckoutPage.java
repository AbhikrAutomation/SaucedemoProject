package org.com.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.com.base.BaseMethodClass;

public class CheckoutPage extends BaseMethodClass {


	@FindBy(xpath = "//input[@id='first-name']")
	WebElement firstName;

	@FindBy(xpath = "//input[@id='last-name']")
	WebElement lastName;


	@FindBy(xpath = "//input[@id='postal-code']")
	WebElement postalCode;

	@FindBy(xpath = "//input[@id='continue']")
	WebElement Continue;

	@FindBy(xpath = "//button[@id='finish']")
	WebElement finish;


	public CheckoutPage() {
		
		PageFactory.initElements(driver, this);
	}
	

	
	public void entercontactsDetails(String fName, String LName , String pCode) throws InterruptedException {


		firstName.sendKeys(fName);
		lastName.sendKeys(LName);
		postalCode.sendKeys(pCode);
		Thread.sleep(2000);
		Continue.click();
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,250)", "");
		Thread.sleep(3000);
		finish.click();
		Thread.sleep(3000);
		js.executeScript("window.scrollBy(0,-550)", "");
		Thread.sleep(3000);

	}

}
