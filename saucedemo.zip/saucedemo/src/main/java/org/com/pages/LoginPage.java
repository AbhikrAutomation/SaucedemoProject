package org.com.pages;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.com.base.BaseMethodClass;
import org.testng.AssertJUnit;

public class LoginPage extends BaseMethodClass{

	@FindBy(xpath="//input[@id='user-name']")
	WebElement username;

	@FindBy(xpath="//input[@id='password']")
	WebElement password;

	@FindBy(xpath="//input[@id='login-button']")
	WebElement loginBtn;

	public LoginPage()
	{
		PageFactory.initElements(driver, this);
	}

	public String validateLoginPage() {

		return driver.getTitle();
	}

	public InventoryPage login(String un, String pwd) {
		username.sendKeys(un);
		password.sendKeys(pwd);
		loginBtn.click();

		return new InventoryPage();
	}
}
