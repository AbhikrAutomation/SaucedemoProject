package org.com.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.com.base.BaseMethodClass;
import org.openqa.selenium.support.ui.Select;

public class InventoryPage extends BaseMethodClass {



	@FindBy(className = "product_sort_container")
	WebElement sortProduct;

	@FindBy(xpath = "//button[@id='add-to-cart-sauce-labs-backpack']")
	WebElement secondCostlierProduct;

	@FindBy(xpath = "//button[@id='add-to-cart-sauce-labs-onesie']")
	WebElement cheapestProduct;

	@FindBy(xpath = "//div[@id='shopping_cart_container']")
	WebElement container;
	
	
	public InventoryPage()
	{
		PageFactory.initElements(driver, this);
	}
	
	public String ValidateInventoryPage()
	{
		return driver.getTitle();
		
	}

	public CartPage addItems() throws InterruptedException {
		Select dropdown = new Select(sortProduct);
		Thread.sleep(3000);
		dropdown.selectByVisibleText("Price (high to low)");
		Thread.sleep(3000);
		secondCostlierProduct.click();
		Thread.sleep(3000);
		cheapestProduct.click();
		Thread.sleep(2000);
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,-350)", "");
		Thread.sleep(3000);
		container.click();
		Thread.sleep(3000);



		return new CartPage();



	}
}


