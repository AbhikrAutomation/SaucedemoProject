package org.com.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import org.com.base.BaseMethodClass;

public class CartPage extends BaseMethodClass {

	@FindBy(xpath = "//button[@id='checkout']")
	WebElement CheckOut;



	public  CartPage() {

		PageFactory.initElements(driver, this);
	}

	public CheckoutPage checkItems() throws InterruptedException {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0, 250)", "");
		Thread.sleep(3000);
		CheckOut.click();
		Thread.sleep(3000);
		return new CheckoutPage();


	}
}

